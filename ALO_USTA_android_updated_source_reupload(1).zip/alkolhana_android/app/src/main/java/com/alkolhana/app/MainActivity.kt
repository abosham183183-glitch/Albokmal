package com.alkolhana.app

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.content.Context
import android.content.ActivityNotFoundException
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.storage.FirebaseStorage
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

private val Navy = Color(0xFF24476A)
private val Gold = Color(0xFFC9A23F)
private val SoftBlue = Color(0xFF8DBDEB)
private val Canvas = Color(0xFFF7F8FA)
private val Ink = Color(0xFF1D2939)
private val Muted = Color(0xFF667085)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
        } catch (_: Exception) { }
        setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { AlkolhanaApp() } }
    }
}

data class CraftCard(
    val id: String = "", val name: String = "", val profession: String = "", val province: String = "",
    val phone: String = "", val desc: String = "", val avatar: String = "", val images: List<String> = emptyList(), val ownerUid: String = "", val ownerEmail: String = ""
)

@Composable
fun AlkolhanaApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var cards by remember { mutableStateOf<List<CraftCard>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var selectedCard by remember { mutableStateOf<CraftCard?>(null) }
    var selectedSection by remember { mutableStateOf<String?>(null) }
    var selectedProfession by remember { mutableStateOf<String?>(null) }
    var zoomImage by remember { mutableStateOf<String?>(null) }
    var currentUser by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser) }
    var showCreate by remember { mutableStateOf(false) }
    var showAdmin by remember { mutableStateOf(false) }
    var authMessage by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    SideEffect { appContext = context.applicationContext }
    val googleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
            val token = account.idToken
            if (token.isNullOrBlank()) {
                authMessage = "لم يصل رمز Google. تحقق من Web Client ID وإعداد OAuth في Firebase."
            } else {
                val credential = GoogleAuthProvider.getCredential(token, null)
                FirebaseAuth.getInstance().signInWithCredential(credential)
                    .addOnSuccessListener { currentUser = it.user; authMessage = "تم تسجيل الدخول بنجاح" }
                    .addOnFailureListener { authMessage = "فشل ربط حساب Google مع Firebase: ${it.localizedMessage ?: "خطأ غير معروف"}" }
            }
        } catch (e: com.google.android.gms.common.api.ApiException) {
            authMessage = when (e.statusCode) {
                12501 -> "ألغيت عملية اختيار حساب Google. لم يتم تسجيل الدخول."
                10 -> "خطأ إعداد Google Sign-In (DEVELOPER_ERROR). أضف SHA-1 وSHA-256 لتطبيق Android في Firebase وتأكد من OAuth Client ID."
                else -> "تعذر اختيار حساب Google. رمز الخطأ: ${e.statusCode}"
            }
        } catch (e: Exception) {
            authMessage = "تعذر إكمال تسجيل الدخول: ${e.localizedMessage ?: "خطأ غير معروف"}"
        }
    }
    DisposableEffect(Unit) { val listener = FirebaseAuth.AuthStateListener { currentUser = it.currentUser }; FirebaseAuth.getInstance().addAuthStateListener(listener); onDispose { FirebaseAuth.getInstance().removeAuthStateListener(listener) } }
    BackHandler(enabled = zoomImage != null || showCreate || showAdmin || selectedCard != null || selectedSection != null || selectedProfession != null) {
        when { zoomImage != null -> zoomImage = null; showCreate -> showCreate = false; showAdmin -> showAdmin = false; selectedCard != null -> selectedCard = null; selectedSection != null -> selectedSection = null; selectedProfession != null -> selectedProfession = null }
    }

    fun mapCardDocuments(snapshot: com.google.firebase.firestore.QuerySnapshot) {
        cards = snapshot.documents.map { d ->
            CraftCard(
                id = d.id, name = d.getString("name") ?: "",
                profession = d.getString("profession") ?: "حرفي",
                province = d.getString("province") ?: "",
                phone = d.getString("phone") ?: "", desc = d.getString("desc") ?: "",
                avatar = d.getString("avatar") ?: "",
                images = (d.get("images") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                ownerUid = d.getString("ownerUid") ?: "", ownerEmail = d.getString("ownerEmail") ?: ""
            )
        }
        loading = false
        error = false
    }

    fun loadCards() {
        loading = true; error = false
        try {
            FirebaseFirestore.getInstance().collection("cards")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
                .get().addOnSuccessListener { mapCardDocuments(it) }
                .addOnFailureListener { loading = false; error = true }
        } catch (_: Exception) { loading = false; error = true }
    }

    DisposableEffect(Unit) {
        val registration = try {
            FirebaseFirestore.getInstance().collection("cards")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
                .addSnapshotListener { snapshot, exception ->
                    if (exception != null) {
                        error = true
                        loading = false
                    } else if (snapshot != null) {
                        mapCardDocuments(snapshot)
                    }
                }
        } catch (_: Exception) {
            error = true
            loading = false
            null
        }
        onDispose { registration?.remove() }
    }
    val filtered = cards.filter {
        val q = search.trim()
        q.isEmpty() || it.name.contains(q, true) || it.profession.contains(q, true) || it.province.contains(q, true)
    }

    Scaffold(containerColor = Canvas, bottomBar = {
        NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
            NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0; selectedCard = null }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
            NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1; selectedCard = null }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("بحث") })
            NavigationBarItem(selected = showCreate, onClick = { if (currentUser == null) selectedTab = 3 else showCreate = true }, icon = { Icon(Icons.Default.AddCircle, null, tint = Color(0xFF168B54)) }, label = { Text("إنشاء", color = Color(0xFF168B54)) })
            NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; selectedCard = null }, icon = { Icon(Icons.Default.LocationOn, null) }, label = { Text("المحافظات") })
            NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3; selectedCard = null }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (showCreate) CreateCardScreen(currentUser = currentUser, onBack = { showCreate = false }, onSaved = { showCreate = false; loadCards() })
            else if (showAdmin) AdminScreen(currentUser = currentUser, cards = cards, onBack = { showAdmin = false }, onRefresh = { loadCards() })
            else if (selectedCard != null) CardDetail(selectedCard!!, onBack = { selectedCard = null }, onZoom = { zoomImage = it })
            else if (selectedSection != null) NativeInfoScreen(section = selectedSection!!, onBack = { selectedSection = null })
            else if (selectedProfession != null) ProfessionCardsScreen(profession = selectedProfession!!, cards = cards, onBack = { selectedProfession = null }, onCard = { selectedCard = it }, onZoom = { zoomImage = it })
            else when (selectedTab) {
                0 -> HomeScreen(cards = filtered, loading = loading, error = error, search = search, onSearch = { search = it }, onCard = { selectedCard = it }, onZoom = { zoomImage = it }, onRefresh = { loadCards() }, onBrowse = { selectedTab = 2 }, onCreate = { if (currentUser == null) selectedTab = 3 else showCreate = true }, onSection = { selectedSection = it }, onProfession = { selectedProfession = it })
                1 -> SearchScreen(cards = filtered, search = search, onSearch = { search = it }, onCard = { selectedCard = it }, onZoom = { zoomImage = it }, loading = loading)
                2 -> DirectoryScreen(cards = cards, onCard = { selectedCard = it }, onZoom = { zoomImage = it })
                else -> ProfileScreen(userEmail = currentUser?.email ?: "", authMessage = authMessage, onSection = { selectedSection = it }, onLogin = {
                    val options = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestIdToken("1023417950981-hac23gg9mh76lmhn52rfsmlq6et1er88.apps.googleusercontent.com").build()
                    GoogleSignIn.getClient(context, options).signOut().addOnCompleteListener { googleLauncher.launch(GoogleSignIn.getClient(context, options).signInIntent) }
                }, onLogout = { FirebaseAuth.getInstance().signOut(); GoogleSignIn.getClient(context, GoogleSignInOptions.DEFAULT_SIGN_IN).signOut(); currentUser = null }, onCreate = { showCreate = true }, onAdmin = { showAdmin = true }, isAdmin = currentUser?.email == "abosham750750@gmail.com")
            }
        }
    }
    if (zoomImage != null) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { zoomImage = null }) {
            var imageScale by remember(zoomImage) { mutableFloatStateOf(1f) }
            val imageTransform = rememberTransformableState { zoomChange, _, _ -> imageScale = (imageScale * zoomChange).coerceIn(1f, 5f) }
            Box(Modifier.fillMaxWidth().background(Color.Black, RoundedCornerShape(16.dp)).padding(8.dp)) {
                AsyncImage(model = zoomImage, contentDescription = "صورة مكبرة - كبّر أو صغّر بإصبعين", modifier = Modifier.fillMaxWidth().heightIn(max = 560.dp).graphicsLayer(scaleX = imageScale, scaleY = imageScale).transformable(imageTransform))
                IconButton(onClick = { zoomImage = null }, modifier = Modifier.align(Alignment.TopEnd).background(Color.Black.copy(alpha = 0.65f), CircleShape)) { Icon(Icons.Default.Close, "إغلاق الصورة", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Gold), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Handyman, null, tint = Navy, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("ALO USTA", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text("كل خدماتك وأساتذتك بمكان واحد", color = Color(0xFFD9E2EF), fontSize = 12.sp)
        }
        Icon(Icons.Default.NotificationsNone, null, tint = Color.White, modifier = Modifier.size(25.dp))
    }
}

@Composable
private fun HomeScreen(cards: List<CraftCard>, loading: Boolean, error: Boolean, search: String, onSearch: (String) -> Unit, onCard: (CraftCard) -> Unit, onRefresh: () -> Unit, onBrowse: () -> Unit, onZoom: (String) -> Unit, onCreate: () -> Unit, onSection: (String) -> Unit, onProfession: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header() }
        item {
            Column(Modifier.padding(16.dp)) {
                Text("أهلاً بك في ALO USTA", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(5.dp))
                Text("اعثر على الحرفي المناسب، قريباً منك.", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("ابحث عن حرفي أو مهنة أو محافظة") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White))
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickTile("تصفح المهن", Icons.Default.Handyman, Modifier.weight(1f), { onProfession("كل المهن") })
                    QuickTile("كل المحافظات", Icons.Default.LocationOn, Modifier.weight(1f), onBrowse)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onCreate, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168B54))) { Icon(Icons.Default.AddCircle, null); Spacer(Modifier.width(5.dp)); Text("أنشئ بطاقتك") }
                    OutlinedButton(onClick = { onSection("من نحن") }, modifier = Modifier.weight(1f)) { Text("من نحن") }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { onSection("الأسئلة الشائعة") }) { Text("الأسئلة الشائعة") }
                    TextButton(onClick = { onSection("أذكار وتسبيحات") }) { Text("الأذكار والتسبيحات") }
                    TextButton(onClick = { onSection("المهن والحرف") }) { Text("المهن") }
                }
                Text("معرض ALO USTA", color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    (1..5).forEach { n -> AsyncImage(model = "https://abosham183183-glitch.github.io/Albokmal/abo$n.png", contentDescription = "معرض ALO USTA $n", modifier = Modifier.size(width = 230.dp, height = 118.dp).clip(RoundedCornerShape(15.dp))) }
                }
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("حرفيون وبطاقات حديثة", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink, modifier = Modifier.weight(1f))
                    TextButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("تحديث") }
                }
            }
        }
        when {
            loading -> item { CenterMessage("جارٍ تحميل البطاقات…", Icons.Default.HourglassTop) }
            error -> item { CenterMessage("تعذر الاتصال بقاعدة البيانات. تحقق من اتصال الإنترنت وإعدادات Firebase.", Icons.Default.CloudOff) }
            cards.isEmpty() -> item { CenterMessage("لا توجد بطاقات منشورة حالياً", Icons.Default.PersonSearch) }
            else -> items(cards.take(30), key = { it.id }) { CraftCardItem(it, onClick = { onCard(it) }, onZoom = onZoom) }
        }
    }
}

@Composable
private fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFFFF4D8)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Navy) }
        Spacer(Modifier.width(8.dp)); Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
private fun CardPhoto(url: String, modifier: Modifier, description: String, circular: Boolean = false) {
    val context = LocalContext.current
    var failed by remember(url) { mutableStateOf(false) }
    val shape = if (circular) CircleShape else RoundedCornerShape(10.dp)
    Box(modifier.clip(shape).background(Color(0xFFEAF0F7)), contentAlignment = Alignment.Center) {
        if (!failed && url.isNotBlank()) {
            AsyncImage(
                model = remember(url) {
                    ImageRequest.Builder(context)
                        .data(url.trim())
                        .crossfade(true)
                        .build()
                },
                contentDescription = description,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().clip(shape),
                onError = { failed = true }
            )
        } else {
            Icon(
                if (circular) Icons.Default.Person else Icons.Default.BrokenImage,
                contentDescription = null,
                tint = Navy,
                modifier = Modifier.size(if (circular) 30.dp else 25.dp)
            )
        }
    }
}

@Composable
private fun CraftCardItem(card: CraftCard, onClick: () -> Unit, onZoom: (String) -> Unit = {}) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (card.avatar.isNotBlank()) CardPhoto(card.avatar, Modifier.size(62.dp).clickable { onZoom(card.avatar) }, "الصورة الشخصية - تكبير", circular = true)
            else Box(Modifier.size(62.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFEAF0F7)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(30.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(card.name.ifBlank { "حرفي" }, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                Text(card.profession, color = Color(0xFF9A6C15), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LocationOn, null, tint = Muted, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(3.dp)); Text(card.province.ifBlank { "سوريا" }, color = Muted, fontSize = 12.sp) }
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Muted)
        }
        if (card.desc.isNotBlank()) Text(card.desc, color = Muted, fontSize = 12.sp, maxLines = 2, modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp))
        if (card.images.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                card.images.take(8).forEach { photo -> CardPhoto(photo, Modifier.size(76.dp).clickable { onZoom(photo) }, "صورة من الأعمال - تكبير") }
            }
            TextButton(onClick = onClick, modifier = Modifier.align(Alignment.End).padding(end = 8.dp)) { Text("عرض الكل (${card.images.size})") }
        }
        Row(Modifier.fillMaxWidth().padding(start = 14.dp, end = 14.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ContactButton("اتصال", Icons.Default.Call, Modifier.weight(1f)) { openDial(card.phone) }
            ContactButton("واتساب", Icons.Default.Chat, Modifier.weight(1f)) { openWhatsApp(card.phone, card.name) }
        }
    }
}


private val appProfessions = listOf("كهربائي", "سباك", "نجار", "حداد", "بناء وديكور", "دهان", "بلاط وسيراميك", "ألمنيوم وزجاج", "خياط", "حلاق", "ميكانيك سيارات", "صيانة موبايلات", "تدفئة وتكييف", "طاقة شمسية", "صيانة أجهزة منزلية", "أخرى")

@Composable
private fun ProfessionCardsScreen(profession: String, cards: List<CraftCard>, onBack: () -> Unit, onCard: (CraftCard) -> Unit, onZoom: (String) -> Unit) {
    var chosen by remember(profession) { mutableStateOf(profession) }
    BackHandler(enabled = chosen != "كل المهن") { chosen = "كل المهن" }
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Navy), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, "رجوع", tint = Color.White) }
            Text("المهن والحرف", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        if (chosen == "كل المهن") {
            LazyColumn(contentPadding = PaddingValues(12.dp)) {
                items(appProfessions) { job ->
                    val count = cards.count { it.profession.equals(job, true) }
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { chosen = job }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Handyman, null, tint = Gold); Spacer(Modifier.width(12.dp)); Text(job, color = Ink, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold); Text("$count", color = Muted)
                        }
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { chosen = "كل المهن" }) { Icon(Icons.Default.ArrowForward, null) }
                Text("معلمو $chosen", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            val matches = cards.filter { it.profession.equals(chosen, true) }
            if (matches.isEmpty()) CenterMessage("لا توجد بطاقات مسجلة بهذه المهنة حالياً", Icons.Default.PersonSearch)
            else LazyColumn { items(matches, key = { it.id }) { CraftCardItem(it, onClick = { onCard(it) }, onZoom = onZoom) } }
        }
    }
}

@Composable
private fun SearchScreen(cards: List<CraftCard>, search: String, onSearch: (String) -> Unit, onCard: (CraftCard) -> Unit, onZoom: (String) -> Unit, loading: Boolean) {
    Column(Modifier.fillMaxSize()) {
        Header()
        Column(Modifier.padding(16.dp)) {
            Text("ابحث عن حرفي", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("الاسم، المهنة، المحافظة…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(8.dp)); Text("النتائج: ${cards.size}", color = Muted, fontSize = 13.sp)
        }
        if (loading) CenterMessage("جارٍ تحميل النتائج…", Icons.Default.HourglassTop)
        else LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) { items(cards, key = { it.id }) { CraftCardItem(it, onClick = { onCard(it) }, onZoom = onZoom) } }
    }
}

@Composable
private fun DirectoryScreen(cards: List<CraftCard>, onCard: (CraftCard) -> Unit, onZoom: (String) -> Unit) {
    val provinces = listOf("دمشق", "ريف دمشق", "حلب", "حمص", "حماة", "اللاذقية", "طرطوس", "إدلب", "دير الزور", "الحسكة", "الرقة", "درعا", "السويداء", "القنيطرة")
    var chosen by remember { mutableStateOf("") }
    BackHandler(enabled = chosen.isNotEmpty()) { chosen = "" }
    Column(Modifier.fillMaxSize()) {
        Header()
        if (chosen.isEmpty()) {
            Column(Modifier.padding(16.dp)) {
                Text("تصفح حسب المحافظة", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("اختر المحافظة لعرض الحرفيين المتاحين", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                provinces.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                        pair.forEach { province ->
                            val count = cards.count { it.province == province }
                            Card(Modifier.weight(1f).clickable { chosen = province }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocationCity, null, tint = Gold, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(8.dp))
                                    Column { Text(province, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp); Text("$count حرفي", color = Muted, fontSize = 11.sp) }
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(8.dp)); Text("أو تصفح كل الحرفيين", color = Navy, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { chosen = "الكل" }.padding(8.dp))
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { chosen = "" }) { Icon(Icons.Default.ArrowForward, null) }
                Text(if (chosen == "الكل") "كل الحرفيين" else "حرفيو $chosen", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
            val list = if (chosen == "الكل") cards else cards.filter { it.province == chosen }
            if (list.isEmpty()) CenterMessage("لا توجد بطاقات في هذه المحافظة حتى الآن", Icons.Default.PersonSearch)
            else LazyColumn { items(list, key = { it.id }) { CraftCardItem(it, onClick = { onCard(it) }, onZoom = onZoom) } }
        }
    }
}

@Composable
private fun CardDetail(card: CraftCard, onBack: () -> Unit, onZoom: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, "إغلاق", tint = Color.White) }
            Text("تفاصيل البطاقة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(contentPadding = PaddingValues(16.dp)) {
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (card.avatar.isNotBlank()) CardPhoto(card.avatar, Modifier.size(100.dp).clickable { onZoom(card.avatar) }, "الصورة الشخصية", circular = true)
                        else Box(Modifier.size(100.dp).clip(CircleShape).background(Color(0xFFEAF0F7)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(52.dp)) }
                        Spacer(Modifier.height(12.dp)); Text(card.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
                        Text(card.profession, color = Color(0xFF9A6C15), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(14.dp)); InfoLine(Icons.Default.LocationOn, "المحافظة", card.province)
                        InfoLine(Icons.Default.Phone, "الهاتف", card.phone)
                        if (card.desc.isNotBlank()) InfoLine(Icons.Default.Description, "نبذة عن العمل", card.desc)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            ContactButton("اتصال", Icons.Default.Call, Modifier.weight(1f)) { openDial(card.phone) }
                            ContactButton("واتساب", Icons.Default.Chat, Modifier.weight(1f)) { openWhatsApp(card.phone, card.name) }
                        }
                    }
                }
            }
            if (card.images.isNotEmpty()) item { Text("صور الأعمال", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(vertical = 14.dp)) }
            items(card.images) { url -> CardPhoto(url, Modifier.fillMaxWidth().heightIn(min = 170.dp, max = 260.dp).padding(bottom = 10.dp).clickable { onZoom(url) }, "صورة عمل - اضغط للتكبير") }
        }
    }
}

@Composable
private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(10.dp))
        Column { Text(label, color = Muted, fontSize = 12.sp); Text(value.ifBlank { "غير مضاف" }, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
    }
}

@Composable
private fun ProfileScreen(userEmail: String, authMessage: String, onSection: (String) -> Unit, onLogin: () -> Unit, onLogout: () -> Unit, onCreate: () -> Unit, onAdmin: () -> Unit, isAdmin: Boolean) {
    Column(Modifier.fillMaxSize()) {
        Header()
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.AccountCircle, null, tint = Gold, modifier = Modifier.size(66.dp))
                        Text(if (userEmail.isBlank()) "حسابك على ALO USTA" else userEmail, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
                        if (userEmail.isBlank()) {
                            Button(onClick = onLogin, colors = ButtonDefaults.buttonColors(containerColor = Navy), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Login, null); Spacer(Modifier.width(8.dp)); Text("تسجيل الدخول باستخدام Google") }
                            if (authMessage.isNotBlank()) Text(authMessage, color = if (authMessage.contains("بنجاح")) Color(0xFF168B54) else Color(0xFFB42318), fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 10.dp))
                        } else {
                            Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Gold), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AddCard, null); Spacer(Modifier.width(8.dp)); Text("إنشاء / إدارة بطاقتي", color = Navy) }
                            if (isAdmin) OutlinedButton(onClick = onAdmin, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.AdminPanelSettings, null); Spacer(Modifier.width(8.dp)); Text("لوحة الإدارة") }
                            TextButton(onClick = onLogout) { Text("تسجيل الخروج") }
                        }
                    }
                }
            }
            items(listOf("من نحن", "الأسئلة الشائعة", "الشكاوى والدعم", "أذكار وتسبيحات", "المهن والحرف")) { title ->
                Card(Modifier.fillMaxWidth().clickable { onSection(title) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(when(title) { "الشكاوى والدعم" -> Icons.Default.SupportAgent; "الأسئلة الشائعة" -> Icons.Default.Quiz; "أذكار وتسبيحات" -> Icons.Default.AutoAwesome; "المهن والحرف" -> Icons.Default.Handyman; else -> Icons.Default.Info }, null, tint = Gold)
                        Spacer(Modifier.width(12.dp)); Text(title, color = Ink, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                    }
                }
            }
        }
    }
}

private val faqContent = listOf(
    "ما هي منصة «ALO USTA»؟" to "هي منصة إلكترونية تجمع الحرفيين والصنايعية وأصحاب المهن الحرة في سوريا، وتساعد الباحثين عن خدمة على استعراض البطاقات حسب المهنة والمحافظة والتواصل مع صاحب المهنة مباشرة.",
    "ماذا تقدم المنصة لأصحاب المهن؟" to "تتيح لصاحب المهنة إنشاء بطاقة تعريفية تتضمن اسمه ومهنته ومحافظته ووسائل التواصل ووصفًا عن خبرته وصورًا من أعماله، ليتمكن الزبائن وأصحاب العمل من التعرف على خدماته.",
    "كيف أجد معلمًا أو حرفيًا؟" to "تصفح البطاقات، أو اختر المحافظة أو قسم المهنة المناسب، ثم راجع معلومات البطاقة والصور المتاحة وتواصل مع صاحبها عبر وسيلة الاتصال المعروضة.",
    "هل يمكنني التواصل مباشرة مع صاحب البطاقة؟" to "نعم، يمكن التواصل مباشرة باستخدام رقم الهاتف أو واتساب إذا كانت وسيلة التواصل متاحة في البطاقة. لا تتوسط المنصة في الاتفاق بين الطرفين.",
    "هل إنشاء البطاقة مجاني؟" to "بحسب المزايا المعروضة حاليًا في الموقع، إنشاء البطاقة والنشر مجانيان ولا تُفرض عمولة من المنصة على الاتفاق بين صاحب العمل والحرفي. راجع أي تعليمات ظاهرة داخل الموقع عند النشر.",
    "ما الصور والمعلومات التي يُفضّل إضافتها؟" to "أضف اسمًا واضحًا، والمهنة والمحافظة، ووصفًا صادقًا لخدماتك وخبرتك، وصورًا حقيقية لأعمالك. لا تنشر معلومات مضللة أو صورًا لا تملك حق استخدامها.",
    "ماذا أفعل إذا وجدت بطاقة مخالفة أو اشتبهت بمحاولة احتيال؟" to "استخدم قسم الشكاوى والدعم في الموقع للتواصل مع الإدارة والإبلاغ عن المشكلة. تحقّق من هوية مقدم الخدمة واتفق على السعر والتفاصيل بوضوح قبل بدء العمل.",
    "هل تضمن المنصة جودة العمل أو الاتفاق المالي؟" to "المنصة تساعد على عرض البطاقات والتواصل، لكنها لا تحل محل التحقق الشخصي ولا تضمن نتيجة العمل أو الاتفاق المالي. اطلب تفاصيل واضحة وراجع الأعمال السابقة واتفق مع مقدم الخدمة مباشرة."
)

@Composable
private fun NativeInfoScreen(section: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, "إغلاق", tint = Color.White) }
            Text(section, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        when (section) {
            "من نحن" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("من نحن؟ وما الذي تقدمه منصة «ALO USTA»؟", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                item { Text("«ALO USTA» منصة خدمية إلكترونية تهدف إلى جمع الصنايعية والحرفيين وأصحاب المهن الحرة في مكان واحد، ومساعدة الناس على الوصول إلى المعلم المناسب بسهولة حسب المهنة والمحافظة. تتيح المنصة لكل صاحب مهنة إنشاء بطاقة تعريفية تعرض معلوماته وخبراته وصورًا من أعماله، وتمنح أصحاب العمل وسيلة أسهل للتعرّف على مقدمي الخدمات والتواصل معهم مباشرة.", color = Ink, fontSize = 15.sp, lineHeight = 27.sp) }
                item { Text("تضم المنصة مجالات متنوعة مثل البلاط والسيراميك، والدهان، والبناء، والإكساء والتشطيبات، والكهرباء، والسباكة، والنجارة وغيرها من المهن. دور المنصة هو تسهيل العثور على أصحاب المهن وعرض أعمالهم؛ ويُنصح المستخدمون بالتأكد من التفاصيل والاتفاق على السعر والموعد مباشرة مع مقدم الخدمة قبل بدء العمل.", color = Ink, fontSize = 15.sp, lineHeight = 27.sp) }
                item { AboutBlock("للباحثين عن عمل", listOf("بطاقة مهنية احترافية باسمك وصورك ومعلوماتك.", "ظهور مباشر أمام أصحاب العمل في محافظتك.", "تواصل فوري عبر الاتصال والواتساب بدون وسطاء.")) }
                item { AboutBlock("لأصحاب العمل", listOf("ابحث بالحرفة أو المحافظة وشوف الأعمال قبل التواصل.", "آلاف الصنايعية الموثوقين بمكان واحد.", "تواصل مباشر الفور مع من يناسبك.")) }
                item { AboutBlock("مميزات المنصة", listOf("نشر مجاني بالكامل وبدون عمولات.", "حتى 50 صورة لعملك (3 صور يوميا مع زر لليوم التالي).", "نظام حماية وإبلاغ ضد المخالفين.")) }
            }
            "الأسئلة الشائعة" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { Text("الأسئلة الشائعة", color = Navy, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("إجابات مختصرة عن أهم الأسئلة حول استخدام منصة «ALO USTA».", color = Muted, fontSize = 14.sp) }
                items(faqContent) { qa -> var expanded by remember { mutableStateOf(false) }; Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) { Column(Modifier.fillMaxWidth().clickable { expanded = !expanded }.padding(15.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { Text(if (expanded) "−" else "+", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.width(9.dp)); Text(qa.first, color = Ink, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)) }; AnimatedVisibility(expanded, enter = fadeIn() + slideInVertically()) { Text(qa.second, color = Muted, fontSize = 14.sp, lineHeight = 24.sp, modifier = Modifier.padding(start = 30.dp, top = 10.dp)) } } } }
            }
            "الشكاوى والدعم" -> LazyColumn(contentPadding = PaddingValues(18.dp)) { item { Text("قسم الشكاوى والدعم", color = Navy, fontSize = 21.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Text("واجهت إعلانا مخالفاً أو محاولة احتيال؟ عندك مشكلة تقنية؟ راسل إدارة «ALO USTA» مباشرة عبر واتساب على الرقم المعتمد — بنراجع كل بلاغ ونتخذ الإجراء اللازم خلال وقت قصير.", color = Ink, fontSize = 15.sp, lineHeight = 27.sp); Spacer(Modifier.height(18.dp)); Button(onClick = { openWhatsApp("380984907588", "إدارة ALO USTA") }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168B54))) { Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text("راسل الإدارة عبر واتساب") } } }
            "المهن والحرف" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(listOf("كهربائي", "سباك", "نجار", "حداد", "بناء وديكور", "دهان", "بلاط وسيراميك", "ألمنيوم وزجاج", "خياط", "حلاق", "ميكانيك سيارات", "صيانة موبايلات", "تدفئة وتكييف", "طاقة شمسية", "صيانة أجهزة منزلية", "أخرى")) { Text(it, color = Ink, modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)).padding(16.dp)) } }
            else -> Column(Modifier.padding(20.dp)) { Text("أذكار وتسبيحات", color = Navy, fontWeight = FontWeight.Bold, fontSize = 21.sp); listOf("سبحان الله", "الحمد لله", "لا إله إلا الله", "الله أكبر", "أستغفر الله العظيم").forEach { Text(it, color = Ink, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) } }
        }
    }
}

@Composable private fun AboutBlock(title: String, lines: List<String>) { Card(colors = CardDefaults.cardColors(containerColor = Color.White)) { Column(Modifier.padding(15.dp)) { Text(title, color = Navy, fontWeight = FontWeight.Bold); lines.forEach { Text("✓  $it", color = Ink, modifier = Modifier.padding(top = 8.dp), lineHeight = 22.sp) } } } }

@Composable
private fun CreateCardScreen(currentUser: com.google.firebase.auth.FirebaseUser?, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var name by remember { mutableStateOf(currentUser?.displayName ?: "") }; var phone by remember { mutableStateOf("") }; var province by remember { mutableStateOf("دمشق") }; var profession by remember { mutableStateOf("كهربائي") }; var desc by remember { mutableStateOf("") }; var avatarUri by remember { mutableStateOf<Uri?>(null) }; var imageUris by remember { mutableStateOf<List<Uri>>(emptyList()) }; var busy by remember { mutableStateOf(false) }; var message by remember { mutableStateOf("") }
    val provinces = listOf("دمشق", "ريف دمشق", "حلب", "حمص", "حماة", "اللاذقية", "طرطوس", "إدلب", "درعا", "السويداء", "القنيطرة", "الرقة", "الحسكة", "دير الزور")
    val professions = listOf("كهربائي", "سباك", "نجار", "حداد", "بناء وديكور", "دهان", "بلاط وسيراميك", "ألمنيوم وزجاج", "خياط", "حلاق", "ميكانيك سيارات", "صيانة موبايلات", "تدفئة وتكييف", "طاقة شمسية", "صيانة أجهزة منزلية", "أخرى")
    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { avatarUri = it }
    val workPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { imageUris = it.take(3) }
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Navy), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.Close, "إغلاق", tint = Color.White) }; Text("أنشئ بطاقتك المهنية", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp) }
        if (currentUser == null) { Text("يجب تسجيل الدخول أولاً", color = Ink, modifier = Modifier.padding(20.dp)) } else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { OutlinedTextField(name, { name = it }, label = { Text("الاسم الثلاثي *") }, modifier = Modifier.fillMaxWidth()) }
            item { OutlinedTextField(phone, { phone = it }, label = { Text("رقم الهاتف (واتساب) *") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth()) }
            item { Text("المحافظة"); DropdownMenuBoxCompat(province, provinces) { province = it } }
            item { Text("المهنة"); DropdownMenuBoxCompat(profession, professions) { profession = it } }
            item { OutlinedTextField(desc, { desc = it }, label = { Text("وصف مختصر عنك وعن خبرتك") }, modifier = Modifier.fillMaxWidth(), minLines = 3) }
            item { Button(onClick = { avatarPicker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Icon(Icons.Default.AccountCircle, null); Text("اختر الصورة الشخصية") }; avatarUri?.let { AsyncImage(it, null, Modifier.size(82.dp).clip(CircleShape)) } }
            item { Button(onClick = { workPicker.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Icon(Icons.Default.AddPhotoAlternate, null, tint = Navy); Text("اختر صور أعمالك (حتى 3 صور)", color = Navy) }; Row(Modifier.horizontalScroll(rememberScrollState())) { imageUris.forEach { AsyncImage(it, null, Modifier.size(90.dp).padding(4.dp).clip(RoundedCornerShape(12.dp))) } } }
            item { if (message.isNotBlank()) Text(message, color = Color(0xFFB42318)); Button(onClick = {
                if (name.trim().split(" ").filter { it.isNotBlank() }.size < 3 || phone.isBlank() || profession.isBlank() || imageUris.isEmpty()) { message = "أدخل الاسم الثلاثي والهاتف والمهنة وصورة عمل واحدة على الأقل."; return@Button }
                busy = true; message = "جارٍ حفظ البطاقة..."
                val storage = FirebaseStorage.getInstance().reference
                fun upload(uri: Uri, path: String, done: (String?) -> Unit) { val ref = storage.child("craft-images/${currentUser.uid}/$path-${System.currentTimeMillis()}"); ref.putFile(uri).continueWithTask { task -> if (!task.isSuccessful) throw task.exception ?: Exception("upload failed"); ref.downloadUrl }.addOnSuccessListener { done(it.toString()) }.addOnFailureListener { done(null) } }
                val urls = mutableListOf<String>(); var avatarUrl: String? = null; var pending = imageUris.size + if (avatarUri != null) 1 else 0; var failed = false
                fun finishOne() { pending--; if (pending == 0) { if (failed || urls.isEmpty()) { busy = false; message = "تعذر رفع الصور. تحقق من تفعيل Firebase Storage وخطته وقواعد الوصول." } else { val doc = hashMapOf<String, Any>("name" to name.trim(), "phone" to phone.trim(), "province" to province, "profession" to profession, "desc" to desc.trim(), "avatar" to (avatarUrl ?: ""), "images" to urls, "imageDescriptions" to urls.map { desc }, "ownerUid" to currentUser.uid, "ownerEmail" to (currentUser.email ?: ""), "isAdminCard" to (currentUser.email == "abosham750750@gmail.com"), "createdAt" to System.currentTimeMillis()); FirebaseFirestore.getInstance().collection("cards").add(doc).addOnSuccessListener { busy = false; onSaved() }.addOnFailureListener { busy = false; message = "تعذر حفظ البطاقة: ${it.localizedMessage}" } } } }
                imageUris.forEachIndexed { i, uri -> upload(uri, "work-$i") { if (it != null) urls.add(it) else failed = true; finishOne() } }; avatarUri?.let { upload(it, "avatar") { avatarUrl = it; if (it == null) failed = true; finishOne() } }; if (pending == 0) { busy = false; message = "لم يتم اختيار الصور" }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text(if (busy) "جارٍ النشر..." else "انشر بطاقتي") } }
        }
    }
}

@Composable private fun DropdownMenuBoxCompat(value: String, options: List<String>, onPick: (String) -> Unit) { var expanded by remember { mutableStateOf(false) }; Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(value, modifier = Modifier.weight(1f)); Icon(Icons.Default.ArrowDropDown, null) }; DropdownMenu(expanded, { expanded = false }) { options.forEach { DropdownMenuItem(text = { Text(it) }, onClick = { onPick(it); expanded = false }) } } } }

@Composable private fun AdminScreen(currentUser: com.google.firebase.auth.FirebaseUser?, cards: List<CraftCard>, onBack: () -> Unit, onRefresh: () -> Unit) { var query by remember { mutableStateOf("") }; var status by remember { mutableStateOf("") }; val admin = currentUser?.email == "abosham750750@gmail.com"; Column(Modifier.fillMaxSize().background(Canvas)) { Row(Modifier.fillMaxWidth().background(Navy), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.Close, "إغلاق", tint = Color.White) }; Text("لوحة الإدارة", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold) }; if (!admin) Text("ليس لديك صلاحية الوصول إلى لوحة الإدارة.", modifier = Modifier.padding(20.dp), color = Ink) else { OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(12.dp), label = { Text("ابحث بالاسم أو الهاتف أو رقم البطاقة") }); Text("إجمالي البطاقات: ${cards.size}", color = Navy, modifier = Modifier.padding(horizontal = 16.dp)); if (status.isNotBlank()) Text(status, color = Muted, modifier = Modifier.padding(8.dp)); LazyColumn { items(cards.filter { query.isBlank() || it.name.contains(query, true) || it.phone.contains(query, true) || it.id.contains(query, true) }, key = { it.id }) { c -> Card(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(c.name, color = Ink, fontWeight = FontWeight.Bold); Text("${c.profession} • ${c.province}", color = Muted); Text("${c.phone}  |  ID: ${c.id}", color = Muted, fontSize = 11.sp) }; IconButton(onClick = { FirebaseFirestore.getInstance().collection("cards").document(c.id).delete().addOnSuccessListener { status = "تم حذف البطاقة"; onRefresh() }.addOnFailureListener { status = "فشل الحذف: ${it.localizedMessage}" } }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFB42318)) } } } } } } } }

@Composable private fun ContactButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) { Button(onClick = onClick, modifier = modifier.height(36.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp), shape = RoundedCornerShape(10.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF168B54))) { Icon(icon, null, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(4.dp)); Text(label, fontSize = 11.sp) } }
private fun openDial(phone: String) { val digits = phone.filter { it.isDigit() }; val number = if (digits.startsWith("0")) "+963" + digits.drop(1) else digits; val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { appContext?.startActivity(intent) } catch (_: Exception) {} }
private var appContext: Context? = null
private fun openWhatsApp(phone: String, name: String) { var digits = phone.filter { it.isDigit() }; if (digits.startsWith("0")) digits = "963" + digits.drop(1); val url = "https://wa.me/$digits?text=" + Uri.encode("مرحبا أستاذ $name، وصلت لبطاقتك على منصة «ALO USTA» وبدي أستفسر 🙏"); val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); try { appContext?.startActivity(intent) } catch (_: Exception) {} }

@Composable
private fun CenterMessage(message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(12.dp)); Text(message, color = Muted, textAlign = TextAlign.Center, fontSize = 14.sp, lineHeight = 22.sp)
    }
}
