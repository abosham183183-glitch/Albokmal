package com.alkolhana.app

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

private val Navy = Color(0xFF24476A)
private val Gold = Color(0xFFC9A23F)
private val SoftBlue = Color(0xFF8DBDEB)
private val Canvas = Color(0xFFF7F8FA)
private val Ink = Color(0xFF1D2939)
private val Muted = Color(0xFF667085)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
        } catch (_: Exception) { }
        setContent { CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { AlkolhanaApp() } }
    }
}

data class CraftCard(
    val id: String = "", val name: String = "", val profession: String = "", val province: String = "",
    val phone: String = "", val desc: String = "", val avatar: String = "", val images: List<String> = emptyList()
)

@Composable
fun AlkolhanaApp() {
    var selectedTab by remember { mutableStateOf(0) }
    var cards by remember { mutableStateOf<List<CraftCard>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var selectedCard by remember { mutableStateOf<CraftCard?>(null) }
    var selectedSection by remember { mutableStateOf<String?>(null) }

    fun mapCardDocuments(snapshot: com.google.firebase.firestore.QuerySnapshot) {
        cards = snapshot.documents.map { d ->
            CraftCard(
                id = d.id, name = d.getString("name") ?: "",
                profession = d.getString("profession") ?: "حرفي",
                province = d.getString("province") ?: "",
                phone = d.getString("phone") ?: "", desc = d.getString("desc") ?: "",
                avatar = d.getString("avatar") ?: "",
                images = (d.get("images") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
            )
        }
        loading = false
        error = false
    }

    fun loadCards() {
        loading = true; error = false
        try {
            FirebaseFirestore.getInstance().collection("cards")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
                .get().addOnSuccessListener { mapCardDocuments(it) }
                .addOnFailureListener { loading = false; error = true }
        } catch (_: Exception) { loading = false; error = true }
    }

    DisposableEffect(Unit) {
        val registration = try {
            FirebaseFirestore.getInstance().collection("cards")
                .orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
                .addSnapshotListener { snapshot, exception ->
                    if (exception != null) {
                        error = true
                        loading = false
                    } else if (snapshot != null) {
                        mapCardDocuments(snapshot)
                    }
                }
        } catch (_: Exception) {
            error = true
            loading = false
            null
        }
        onDispose { registration?.remove() }
    }
    val filtered = cards.filter {
        val q = search.trim()
        q.isEmpty() || it.name.contains(q, true) || it.profession.contains(q, true) || it.province.contains(q, true)
    }

    Scaffold(containerColor = Canvas, bottomBar = {
        NavigationBar(containerColor = Color.White, tonalElevation = 8.dp) {
            NavigationBarItem(selected = selectedTab == 0, onClick = { selectedTab = 0; selectedCard = null }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
            NavigationBarItem(selected = selectedTab == 1, onClick = { selectedTab = 1; selectedCard = null }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("بحث") })
            NavigationBarItem(selected = selectedTab == 2, onClick = { selectedTab = 2; selectedCard = null }, icon = { Icon(Icons.Default.LocationOn, null) }, label = { Text("المحافظات") })
            NavigationBarItem(selected = selectedTab == 3, onClick = { selectedTab = 3; selectedCard = null }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("حسابي") })
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (selectedCard != null) CardDetail(selectedCard!!, onBack = { selectedCard = null })
            else if (selectedSection != null) NativeInfoScreen(section = selectedSection!!, onBack = { selectedSection = null })
            else when (selectedTab) {
                0 -> HomeScreen(cards = filtered, loading = loading, error = error, search = search, onSearch = { search = it }, onCard = { selectedCard = it }, onRefresh = { loadCards() }, onBrowse = { selectedTab = 2 })
                1 -> SearchScreen(cards = filtered, search = search, onSearch = { search = it }, onCard = { selectedCard = it }, loading = loading)
                2 -> DirectoryScreen(cards = cards, onCard = { selectedCard = it })
                else -> ProfileScreen(onSection = { selectedSection = it })
            }
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal = 20.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Gold), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Handyman, null, tint = Navy, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("ALO USTA", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text("كل خدماتك وأساتذتك بمكان واحد", color = Color(0xFFD9E2EF), fontSize = 12.sp)
        }
        Icon(Icons.Default.NotificationsNone, null, tint = Color.White, modifier = Modifier.size(25.dp))
    }
}

@Composable
private fun HomeScreen(cards: List<CraftCard>, loading: Boolean, error: Boolean, search: String, onSearch: (String) -> Unit, onCard: (CraftCard) -> Unit, onRefresh: () -> Unit, onBrowse: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Header() }
        item {
            Column(Modifier.padding(16.dp)) {
                Text("أهلاً بك في ALO USTA", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                Spacer(Modifier.height(5.dp))
                Text("اعثر على الحرفي المناسب، قريباً منك.", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("ابحث عن حرفي أو مهنة أو محافظة") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White))
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    QuickTile("تصفح المهن", Icons.Default.Handyman, Modifier.weight(1f), onBrowse)
                    QuickTile("كل المحافظات", Icons.Default.LocationOn, Modifier.weight(1f), onBrowse)
                }
                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("حرفيون وبطاقات حديثة", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Ink, modifier = Modifier.weight(1f))
                    TextButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("تحديث") }
                }
            }
        }
        when {
            loading -> item { CenterMessage("جارٍ تحميل البطاقات…", Icons.Default.HourglassTop) }
            error -> item { CenterMessage("تعذر الاتصال بقاعدة البيانات. تحقق من اتصال الإنترنت وإعدادات Firebase.", Icons.Default.CloudOff) }
            cards.isEmpty() -> item { CenterMessage("لا توجد بطاقات منشورة حالياً", Icons.Default.PersonSearch) }
            else -> items(cards.take(30), key = { it.id }) { CraftCardItem(it, onClick = { onCard(it) }) }
        }
    }
}

@Composable
private fun QuickTile(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFFFF4D8)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Navy) }
        Spacer(Modifier.width(8.dp)); Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
private fun CraftCardItem(card: CraftCard, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable(onClick = onClick), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            if (card.avatar.isNotBlank()) AsyncImage(model = card.avatar, contentDescription = null, modifier = Modifier.size(62.dp).clip(RoundedCornerShape(15.dp)))
            else Box(Modifier.size(62.dp).clip(RoundedCornerShape(15.dp)).background(Color(0xFFEAF0F7)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(30.dp)) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(card.name.ifBlank { "حرفي" }, color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1)
                Spacer(Modifier.height(5.dp))
                Text(card.profession, color = Color(0xFF9A6C15), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.LocationOn, null, tint = Muted, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(3.dp)); Text(card.province.ifBlank { "سوريا" }, color = Muted, fontSize = 12.sp) }
            }
            Icon(Icons.Default.ChevronLeft, null, tint = Muted)
        }
    }
}

@Composable
private fun SearchScreen(cards: List<CraftCard>, search: String, onSearch: (String) -> Unit, onCard: (CraftCard) -> Unit, loading: Boolean) {
    Column(Modifier.fillMaxSize()) {
        Header()
        Column(Modifier.padding(16.dp)) {
            Text("ابحث عن حرفي", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text("الاسم، المهنة، المحافظة…") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(8.dp)); Text("النتائج: ${cards.size}", color = Muted, fontSize = 13.sp)
        }
        if (loading) CenterMessage("جارٍ تحميل النتائج…", Icons.Default.HourglassTop)
        else LazyColumn(contentPadding = PaddingValues(bottom = 12.dp)) { items(cards, key = { it.id }) { CraftCardItem(it) { onCard(it) } } }
    }
}

@Composable
private fun DirectoryScreen(cards: List<CraftCard>, onCard: (CraftCard) -> Unit) {
    val provinces = listOf("دمشق", "ريف دمشق", "حلب", "حمص", "حماة", "اللاذقية", "طرطوس", "إدلب", "دير الزور", "الحسكة", "الرقة", "درعا", "السويداء", "القنيطرة")
    var chosen by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Header()
        if (chosen.isEmpty()) {
            Column(Modifier.padding(16.dp)) {
                Text("تصفح حسب المحافظة", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink)
                Text("اختر المحافظة لعرض الحرفيين المتاحين", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                provinces.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                        pair.forEach { province ->
                            val count = cards.count { it.province == province }
                            Card(Modifier.weight(1f).clickable { chosen = province }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(16.dp)) {
                                Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocationCity, null, tint = Gold, modifier = Modifier.size(24.dp)); Spacer(Modifier.width(8.dp))
                                    Column { Text(province, fontWeight = FontWeight.Bold, color = Ink, fontSize = 14.sp); Text("$count حرفي", color = Muted, fontSize = 11.sp) }
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                Spacer(Modifier.height(8.dp)); Text("أو تصفح كل الحرفيين", color = Navy, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { chosen = "الكل" }.padding(8.dp))
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { chosen = "" }) { Icon(Icons.Default.ArrowForward, null) }
                Text(if (chosen == "الكل") "كل الحرفيين" else "حرفيو $chosen", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
            }
            val list = if (chosen == "الكل") cards else cards.filter { it.province == chosen }
            if (list.isEmpty()) CenterMessage("لا توجد بطاقات في هذه المحافظة حتى الآن", Icons.Default.PersonSearch)
            else LazyColumn { items(list, key = { it.id }) { CraftCardItem(it) { onCard(it) } } }
        }
    }
}

@Composable
private fun CardDetail(card: CraftCard, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, null, tint = Color.White) }
            Text("تفاصيل البطاقة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        LazyColumn(contentPadding = PaddingValues(16.dp)) {
            item {
                Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (card.avatar.isNotBlank()) AsyncImage(model = card.avatar, contentDescription = null, modifier = Modifier.size(100.dp).clip(CircleShape))
                        else Box(Modifier.size(100.dp).clip(CircleShape).background(Color(0xFFEAF0F7)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(52.dp)) }
                        Spacer(Modifier.height(12.dp)); Text(card.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Ink, textAlign = TextAlign.Center)
                        Text(card.profession, color = Color(0xFF9A6C15), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(14.dp)); InfoLine(Icons.Default.LocationOn, "المحافظة", card.province)
                        InfoLine(Icons.Default.Phone, "الهاتف", card.phone)
                        if (card.desc.isNotBlank()) InfoLine(Icons.Default.Description, "نبذة عن العمل", card.desc)
                    }
                }
            }
            if (card.images.isNotEmpty()) item { Text("صور الأعمال", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.padding(vertical = 14.dp)) }
            items(card.images) { url -> AsyncImage(model = url, contentDescription = "صورة عمل", modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(RoundedCornerShape(16.dp))) }
        }
    }
}

@Composable
private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(21.dp)); Spacer(Modifier.width(10.dp))
        Column { Text(label, color = Muted, fontSize = 12.sp); Text(value.ifBlank { "غير مضاف" }, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
    }
}

@Composable
private fun ProfileScreen(onSection: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header()
        LazyColumn(contentPadding = PaddingValues(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Column(Modifier.fillMaxWidth().padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(82.dp).clip(CircleShape).background(Color(0xFFFFF0CB)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Navy, modifier = Modifier.size(42.dp)) }
                    Spacer(Modifier.height(12.dp)); Text("حسابك على ALO USTA", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                    Text("إدارة حسابك ومعلومات المنصة", fontSize = 13.sp, color = Muted)
                }
            }
            items(listOf("من نحن", "الأسئلة الشائعة", "الشكاوى والدعم", "الأذكار والتسبيحات", "المهن والحرف", "سياسة الخصوصية")) { title ->
                Card(Modifier.fillMaxWidth().clickable { onSection(title) }, colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(15.dp)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(when(title) { "الشكاوى والدعم" -> Icons.Default.SupportAgent; "الأسئلة الشائعة" -> Icons.Default.Quiz; "الأذكار والتسبيحات" -> Icons.Default.AutoAwesome; "المهن والحرف" -> Icons.Default.Handyman; else -> Icons.Default.Info }, null, tint = Gold)
                        Spacer(Modifier.width(12.dp)); Text(title, color = Ink, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronLeft, null, tint = Muted)
                    }
                }
            }
            item { Text("ملاحظة: تسجيل الدخول وإدارة البطاقات سيُفعّلان بعد استكمال ربط Firebase والتحقق من صلاحيات قاعدة البيانات.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp, modifier = Modifier.padding(8.dp)) }
        }
    }
}

@Composable
private fun NativeInfoScreen(section: String, onBack: () -> Unit) {
    val faqs = listOf(
        "كيف أجد حرفياً؟" to "استخدم البحث بالاسم أو المهنة أو المحافظة، ثم افتح بطاقة الحرفي للاطلاع على التفاصيل.",
        "كيف أتواصل مع الحرفي؟" to "افتح بطاقة الحرفي واستخدم رقم الهاتف المعروض للتواصل معه.",
        "كيف أضيف بطاقة؟" to "ستتاح إضافة البطاقة بعد تفعيل تسجيل الدخول والتحقق من صلاحيات الحساب.",
        "هل بيانات الموقع والتطبيق مشتركة؟" to "يعرض التطبيق البطاقات من مجموعة cards في مشروع Firebase نفسه المستخدم للموقع."
    )
    val trades = listOf("بويا ودهان", "بلاط وسيراميك", "إكساء وديكور", "بناء ومقاولات", "كهرباء", "تمديدات صحية", "نجارة", "ألمنيوم", "حدادة", "تكييف وتبريد", "تنظيف", "صيانة عامة")
    Column(Modifier.fillMaxSize().background(Canvas)) {
        Row(Modifier.fillMaxWidth().background(Navy).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, null, tint = Color.White) }
            Text(section, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
        when (section) {
            "من نحن" -> Column(Modifier.padding(20.dp)) {
                Text("ALO USTA", color = Navy, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(12.dp)); Text("منصة تجمع الحرفيين وأصحاب الخدمات في مكان واحد، لتسهيل الوصول إلى أصحاب الخبرة ومشاهدة مجالات عملهم والتواصل معهم.", color = Ink, fontSize = 16.sp, lineHeight = 27.sp)
                Spacer(Modifier.height(12.dp)); Text("هدفنا تنظيم عرض الخدمات المهنية وتسهيل البحث حسب المهنة والمحافظة.", color = Muted, fontSize = 14.sp, lineHeight = 24.sp)
            }
            "الأسئلة الشائعة" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(faqs) { item -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(16.dp)) { Text(item.first, color = Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp); Spacer(Modifier.height(7.dp)); Text(item.second, color = Ink, fontSize = 14.sp, lineHeight = 22.sp) } } }
            }
            "المهن والحرف" -> LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(trades) { trade -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(12.dp)) { Text(trade, color = Ink, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth().padding(16.dp)) } }
            }
            "الأذكار والتسبيحات" -> Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf("سبحان الله", "الحمد لله", "لا إله إلا الله", "الله أكبر", "أستغفر الله العظيم").forEach { phrase -> Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) { Text(phrase, color = Navy, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(20.dp)) } }
            }
            "الشكاوى والدعم" -> Column(Modifier.padding(20.dp)) {
                Text("نسعد باستقبال ملاحظاتك وشكاواك لتحسين المنصة.", color = Ink, fontSize = 16.sp, lineHeight = 25.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { /* رابط الدعم يضاف بعد اعتماد رقم التواصل الرسمي */ }, colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Icon(Icons.Default.SupportAgent, null); Spacer(Modifier.width(8.dp)); Text("الدعم الفني") }
                Text("لم يُضف رقم واتساب أو بريد دعم في ملفات المشروع التي فُحصت، لذلك لم نضع جهة اتصال غير مؤكدة.", color = Muted, fontSize = 12.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 12.dp))
            }
            else -> Column(Modifier.padding(20.dp)) { Text("سيتم عرض السياسة المعتمدة هنا بعد توفير نصها الرسمي.", color = Muted, fontSize = 15.sp) }
        }
    }
}

@Composable
private fun CenterMessage(message: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(12.dp)); Text(message, color = Muted, textAlign = TextAlign.Center, fontSize = 14.sp, lineHeight = 22.sp)
    }
}
